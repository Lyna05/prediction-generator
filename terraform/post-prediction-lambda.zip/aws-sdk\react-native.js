var AWS = require('./lib/react-native-loader');

require('./clients/all');
module.exports = AWS;